package dbstaff;

import java.awt.Container;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.Insets;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JOptionPane;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextArea;

/**
 * 
 * Window implements the sub window that prints all information
 * (database contents, ip and patterns inserted into the system, 
 * active users)
 * 
 */
public class Window extends JFrame implements ActionListener{

	/*
	 * Neccessary UID.
	 */
	private static final long serialVersionUID = 1L;

	/*
	 * Button.
	 */
	private JButton button = null;

	/*
	 * GridBag layout needs constraints.
	 */
	private GridBagConstraints c = null;

	/*
	 * A container that all elements are stored into.
	 */
	private Container pane = null;

	/*
	 * A text area to print information.
	 */
	private JTextArea userText = null;
	private int ave = 0;
	/*
	 * The text area above is contained here so that
	 * it is scrollable.
	 */
	private JScrollPane text = null;

	/*
	 * This vector contains all database tables that are also scrollable.
	 */
	private Vector<JScrollPane> JVector;


	/*
	 * This method is used to add components to a panel.
	 */
	private void addComponentsToPane(JTable[] array){

		// We set the layout options.
		pane.setLayout(new GridBagLayout());
		c = new GridBagConstraints();
		c.fill = GridBagConstraints.HORIZONTAL;



		//adding text area
		userText= new JTextArea("you can write notes here");	
		text = new JScrollPane(userText);
		// We now create a text area
		AreaPanel();

		//adding database panel
		int counter = BasePanel(array);



		//adding refresh button
		button = new JButton("REFRESH");
		c.gridx = counter;
		c.gridy = 3;
		c.ipady = 0;
		c.anchor = GridBagConstraints.PAGE_END;
		c.insets = new Insets(0,100,0,0);
		// now we add it
		pane.add(button, c);
		// and we add a button listener
		button.addActionListener(this);
	}

	/*
	 * JTextArea initialization method
	 */
	private void AreaPanel(){
		text.updateUI();
		c.gridx = 0;
		c.gridy = 0;
		c.weightx = 0.5;
		c.weighty = 10;
		c.gridwidth = 5;
		c.ipady = 40;
		c.anchor = GridBagConstraints.CENTER;
		c.insets = new Insets(0,0,0,0);
		pane.add(text, c);	
	}

	/*
	 * Methode used to initialize the panel used to show DataBase 
	 */
	private int BasePanel(JTable[] array){
		int counter = 0;

		c.gridwidth = 1;
		c.gridx = 0;
		c.gridy = 1;
		c.weighty = 10;
		c.weightx = 0.7;
		c.ipady = 90;
		c.anchor = GridBagConstraints.CENTER;
		c.insets = new Insets(0,0,0,0);
		// For every table in the array we insert it in the vector
		for(JTable t:array){
			JVector.addElement(new JScrollPane(t));
			JVector.lastElement().setVisible(true);
			JVector.lastElement().setAutoscrolls(true);
			JVector.lastElement().setPreferredSize(new Dimension(500, 100));
			JVector.lastElement().setHorizontalScrollBarPolicy( JScrollPane.HORIZONTAL_SCROLLBAR_ALWAYS);
			JVector.lastElement().getHorizontalScrollBar().setUnitIncrement(50);
			pane.add(JVector.lastElement(), c);
			c.gridx ++;
			counter ++;
		}
		return counter-1;
	}

	/*
	 * Constructor.
	 */
	public Window(JTable[] array1, String title){

		// We create a new JFrame
		JFrame frame = new JFrame(title);
		pane = frame.getContentPane();
		// Create new vector
		JVector = new Vector<JScrollPane>(5);
		// and fill it.
		boolean karma=false;
		boolean opalakia=false;
		addComponentsToPane(array1);
		String s="";
		String k="";
		
		
		if(title=="SignalStrength"){
			int[] yolo= new int[14];
			JTable[] array = DB_connection.getSignalStrength();
			for(int i=0;i<14;i++)
				yolo[i]=0;
			for(int i=1; i<(array[0].getRowCount()); i++){
				//System.out.println((array[0].getValueAt(i, 2)));

				yolo[Integer.parseInt((String) (array[0].getValueAt(i, 2))) - 1]+=1;
				
			}
			s="Router channel collision detected:\n";
			for(int i=0;i<14;i++){
				if(yolo[i]>1){
					//System.out.println(yolo[i]);
					karma=true;
					for(int j=1;j<(array[0].getRowCount());j++){
						if(Integer.parseInt((String) (array[0].getValueAt(j, 2)))-1==i){
							s+=array[0].getValueAt(j, 0) + " should go to ";
							//searching for channels that are not interrupted by already active routers
							for(int y=0;y<14;y++){
								if(y==0){
									//if channels 1.2.3 are free
									if(yolo[0]==0&&yolo[1]==0&&yolo[2]==0){
										array[0].setValueAt(1, j, 2);
										yolo[0]++;
										yolo[i]--;

									}
								}
								else if(y==1){
									//if channels 1.2.3 and 4 are free
									if(yolo[0]==0&&yolo[1]==0&&yolo[2]==0&&yolo[3]==0){
										array[0].setValueAt(2, j, 2);
										yolo[1]++;
										yolo[i]--;
									}
								}
								else if(y==13){
									
									//if channels 13.12.14 are free
									if(yolo[13]==0&&yolo[11]==0&&yolo[12]==0){
										array[0].setValueAt(14, j, 2);
										yolo[13]++;
										yolo[i]--;
									}
								}
								else if(y==12){
									//if channels 1.2.3 and 4 are free
									if(yolo[13]==0&&yolo[11]==0&&yolo[12]==0&&yolo[10]==0){
										array[0].setValueAt(13, j, 2);
										yolo[12]++;
										yolo[i]--;
									}
								}	
								//if the prev 2 channels and next 2 
								//are not broadcasting we got no collision
								else if(yolo[y-2]==0 &&
										yolo[y-1]==0 &&
										yolo[y]==0 &&
										yolo[y+1]==0 &&
										yolo[y+2]==0){
									array[0].setValueAt(y+1, j, 2);
									yolo[y]++;
									yolo[i]--;


								}

							}
							s+=array[0].getValueAt(j, 2) + "\n";
							if(yolo[i]<=1)
								break;
						}
						//else if(yolo[i]==0)
						//k+=Integer.toString(i) + ", ";
					}
					}
					}
			if(karma==true){
				SignalWindow w= new SignalWindow(array, s);
					
			}
				karma=false;
				}
				if(title=="Security"){
					s="Router authentication problem detected in:\n";
					for(int i=1; i<(array1[0].getRowCount()); i++){
						//System.out.println(array[0].getValueAt(i, 2));
						if(array1[0].getValueAt(i, 2).equals("DH-ANON")){
							opalakia=true;
							s+= array1[0].getValueAt(i, 0) + ", ";
						}
					}




				}
				frame.setDefaultCloseOperation(DISPOSE_ON_CLOSE);
				frame.pack();
				frame.setVisible(true);
				if(karma==true){
					s+=k;
					JOptionPane.showInputDialog(s);
				}
				if(opalakia==true){
					JOptionPane.showMessageDialog(null, s);
				}
			}


			@Override
			public void actionPerformed(ActionEvent arg0) {


			}

		}
