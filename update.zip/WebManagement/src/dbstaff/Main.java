package dbstaff;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;

public class Main {

	/*
	 * Neccessary UID.
	 */
	//private static final long serialVersionUID = 1L;

	/*
	 * JLabels used in GUI.
	 */
	private static JLabel mainLabel;

	private static JLabel MLabel;

	private static JLabel SLabel;

	/*
	 * Three buttons.
	 */
	private static JButton click1,click2,click3;
	
	public static void main(String[] args) {
		//Schedule a job for the event-dispatching thread:
		//creating and showing this application's GUI.
		javax.swing.SwingUtilities.invokeLater(new Runnable() {
			public void run() {
				createGUI();
			}
		});
	}
	public static void createGUI(){

		//Create and set up the window.
		JFrame frame = new JFrame("HelloWorldSwing");
		ActionListener qq = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// If the first button was pressed
				if( e.getSource() == click1 ) {
					// A dialog prompts the user to insert ip
					synchronized(DB_connection.class){
						// The new window needs the database data in order to print them
						Window w = new 
						Window(DB_connection.getSignalStrength(), "SignalStrength");
					}

				}
				// If the third button was pressed
				if( e.getSource() == click3 ) {
					// A dialog prompts the user to insert pattern
					synchronized(DB_connection.class){
						// The new window needs the database data in order to print them
						Window w = new 
						Window(DB_connection.getSecurity(), "Security");
					}
				}
				// If the second button was pressed
				if( e.getSource() == click2 ) {
					// We create a sub window
					synchronized(DB_connection.class){
						// The new window needs the database data in order to print them
						WiresharkWindow w = new 
						WiresharkWindow(DB_connection.getIPdata(),"Wireshark");
					}
					// The new window needs the database data in order to print them
						//w = new Window(q);
					
					//w.getTitle();
				}
			}
		};
		//Initialize Layout.
		frame.setLayout(null);
		frame.setSize(600,400);
		frame.setTitle("GUI");

		//Create new Labels and Buttons.
		mainLabel = new JLabel ("Hello admin!Choose the operation you want to proceed to :)  ");
		MLabel = new JLabel("Signal Strength/Security");
		SLabel = new JLabel("Get Network Statistics: ");
		click1 = new JButton("SignalStrength");
		click2 = new JButton("Statistics");
		click3 = new JButton("Security");


		//Position the contents of Layout.
		mainLabel.setBounds(90,30,500,100);
		MLabel.setBounds(75,200,230,30);
		SLabel.setBounds(360,200,200,30);
		click1.setBounds(120,245,120,30);
		click2.setBounds(385,260,105,30);
		click3.setBounds(120, 285, 100, 30);

		//Add ActionListeners for the 3 option Buttons.
		click1.addActionListener(qq);
		click2.addActionListener(qq);
		click3.addActionListener(qq);

		// add them to the frame
		frame.add(MLabel);
		frame.add(SLabel);
		frame.add(click1);
		frame.add(click2);
		frame.add(click3);
		frame.add(mainLabel);

		//Exit GUI when (x) Button is pressed.
		frame.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);

		frame.setResizable(true);	
		frame.setVisible(true);
	}

}
