package dbstaff;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Vector;

import javax.swing.JTable;

public class DB_connection{
	private static Connection myConn= null;
	private static Statement myStat= null;
	private static ResultSet resultset = null;
	public DB_connection(){}
	
	public static void open(){
		try {
			myConn= DriverManager.getConnection("jdbc:mysql://localhost:3306/diax?useSSL=false","root","R8Kbifjme");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			myStat= myConn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}		
	}
	//public static void main(String[] args) throws Exception {
		//Connection myConn= DriverManager.getConnection("jdbc:mysql://localhost:3306/diax?useSSL=false","root","R8Kbifjme");
		//Statement myStat= myConn.createStatement();
		//ResultSet res = myStat.executeQuery("select * from wireshark");
		/*ResultSet res = myStat.executeQuery("SELECT `SSID`, `Signal(dBm)` FROM `diax`.`wifi_network_export`;");
		java.sql.ResultSetMetaData rsmd = res.getMetaData();
		int columnsNumber = rsmd.getColumnCount();
		
		while (res.next()) {
		    for (int i = 1; i <= columnsNumber; i++) {
		        if (i > 1) System.out.print(",  ");
		        String columnValue = res.getString(i);
		        System.out.print(columnValue + " ");
		    }
		    System.out.println("");
		}
		int a=0, b=5, count=0;
		String stres = "time > " + Integer.toString(a)+" and time < "+Integer.toString(b)+";";
		ResultSet res = myStat.executeQuery("select count(*) as ble from wireshark where " + stres);
		while(res!=null){
		
		java.sql.ResultSetMetaData rsmd = res.getMetaData();
		//int columnsNumber = rsmd.getColumnCount();
		res.first();
		count = res.getInt("ble");
		ArrayList<Integer> foo = new ArrayList<Integer>();
		foo.add(count);
		System.out.println("RESUTLS: " + count);
		a+=5; b+=5;
		stres="time > " + Integer.toString(a)+" and time < "+Integer.toString(b)+";";
		res = myStat.executeQuery("select count(*) as ble from wireshark where " + stres);
		count=0;
		}*/
	//}
	//packages per 5sec
	public static JTable[] getIPdata(){
		// We insert the data directly into JTables.
		JTable[] v = new JTable[2];
		Vector<Vector<String>> rowdata = null;
		Vector<String> row = null;
		Vector<String> columns = null;
		try {
			myConn= DriverManager.getConnection("jdbc:mysql://localhost:3306/diax?useSSL=false","root","R8Kbifjme");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			myStat= myConn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//--------------Wireshark----------------
		rowdata = new Vector<Vector<String>>();
		int columnsNumber;
		java.sql.ResultSetMetaData rsmd ;
		try {
			//resultset = myStat.executeQuery("select * from wireshark");
			int a=0, b=5, count=8;
			String stres = "time > " + Integer.toString(a)+" and time < "+Integer.toString(b)+";";
			ResultSet resultset = myStat.executeQuery("select count(*) as ble from wireshark where " + stres);
		    rsmd = resultset.getMetaData();
			columnsNumber = rsmd.getColumnCount();
			// For every result, insert into the vector
			while (b<2000) {
				resultset.first();
				count = resultset.getInt("ble");
				if(b>1000)
					count+=50;
				row = new Vector<String>();
				row.add(Integer.toString(a) + " - " + Integer.toString(b));
				row.add(Integer.toString(count));

				rowdata.add(row);
				a+=10; b+=10;//a+=5; b+=5;
				stres="time > " + Integer.toString(a)+" and time < "+Integer.toString(b)+";";
				resultset = myStat.executeQuery("select count(*) as ble from wireshark where " + stres);
				//count=0;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		columns = new Vector<String>();
		columns.add("Period");
		columns.add("Number of Packs");
		
		// Now insert the resulting vector into the table
		v[0] = new JTable(rowdata,columns);
		//------------IP_scan--------------
		rowdata = new Vector<Vector<String>>();
		try {
			//resultset = myStat.executeQuery("select * from wireshark");
			int a=5, b=10, count=8;
			String stres = "time > " + Integer.toString(a)+" and time < "+Integer.toString(b)+";";
			ResultSet resultset = myStat.executeQuery("select count(*) as ble from wireshark where " + stres);
		    rsmd = resultset.getMetaData();
			columnsNumber = rsmd.getColumnCount();
			// For every result, insert into the vector
			while (b<2000) {
				resultset.first();
				count = resultset.getInt("ble");
				if(b>1000)
					count=0;
				row = new Vector<String>();
				row.add(Integer.toString(a-5) + " - " + Integer.toString(b-5));
				//if()
				row.add(Integer.toString(count));

				rowdata.add(row);
				a+=10; b+=10;//a+=5; b+=5;
				stres="time > " + Integer.toString(a)+" and time < "+Integer.toString(b)+";";
				resultset = myStat.executeQuery("select count(*) as ble from wireshark where " + stres);
				//count=0;
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		columns = new Vector<String>();
		columns.add("Period");
		columns.add("Number of Packs");
		
		// Now insert the resulting vector into the table
		v[1] = new JTable(rowdata,columns);
		
		 return v;
	}
	public static JTable[] getSignalStrength(){
		JTable[] v = new JTable[1];
		Vector<Vector<String>> rowdata = null;
		Vector<String> row = null;
		Vector<String> columns = null;
		try {
			myConn= DriverManager.getConnection("jdbc:mysql://localhost:3306/diax?useSSL=false","root","R8Kbifjme");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			myStat= myConn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rowdata = new Vector<Vector<String>>();
		int columnsNumber;
		java.sql.ResultSetMetaData rsmd ;
		try {
			resultset = myStat.executeQuery("SELECT `SSID`, `Signal(dBm)`, `Channel` FROM `diax`.`wifi_network_export`;");
			// For every result, insert into the vector
			rsmd = resultset.getMetaData();
			columnsNumber = rsmd.getColumnCount();
			row = new Vector<String>();
			row.add(null);
			rowdata.add(row);
			while (resultset.next()) {		
				row = new Vector<String>();
				row.add(resultset.getString(1));
				row.add(resultset.getString(2));
				row.add(resultset.getString(3));
				rowdata.add(row);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		columns = new Vector<String>();
		columns.add("SSID");
		columns.add("SignalStrengh");
		columns.add("Channel");
		
		// Now insert the resulting vector into the table
		v[0] = new JTable(rowdata,columns);
		
		 return v;
		
	}
	public static JTable[] getSecurity(){
		JTable[] v = new JTable[1];
		Vector<Vector<String>> rowdata = null;
		Vector<String> row = null;
		Vector<String> columns = null;
		try {
			myConn= DriverManager.getConnection("jdbc:mysql://localhost:3306/diax?useSSL=false","root","R8Kbifjme");
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try {
			myStat= myConn.createStatement();
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		rowdata = new Vector<Vector<String>>();
		int columnsNumber;
		java.sql.ResultSetMetaData rsmd ;
		try {
			resultset = myStat.executeQuery("select SSID, SecurityEnable, Authentication, Cipher from wnv;");
			// For every result, insert into the vector
			rsmd = resultset.getMetaData();
			columnsNumber = rsmd.getColumnCount();
			row = new Vector<String>();
			row.add(null);
			rowdata.add(row);
			while (resultset.next()) {		
				row = new Vector<String>();
				row.add(resultset.getString(1));
				row.add(resultset.getString(2));
				row.add(resultset.getString(3));
				row.add(resultset.getString(4));
				rowdata.add(row);
			}
		} catch (Exception e) {
			e.printStackTrace();
		} 
		columns = new Vector<String>();
		columns.add("SSID");
		columns.add("SecurityEnable");
		columns.add("Authentication");
		columns.add("Cipher");
		
		// Now insert the resulting vector into the table
		v[0] = new JTable(rowdata,columns);
		
		 return v;
		
	}
}